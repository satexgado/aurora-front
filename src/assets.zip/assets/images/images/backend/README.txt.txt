Commence d'abord par rentrer la commande "php artisan storage:link"
Ensuite copie le dossier dans \storage\app\public
