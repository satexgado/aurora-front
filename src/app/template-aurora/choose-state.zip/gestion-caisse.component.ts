import { ChooseAbonnementComponent } from './choose-abonnement/choose-abonnement.component';
import { TicketAvoirFactory } from 'src/app/core/services/caisse/ticket-avoir.factory';
import { ChooseStateComponent } from './choose-state/choose-state.component';
import { MoyenPaiementFactory } from 'src/app/core/services/caisse/moyen-paiment.factory';
import { ITicketArticle, TicketArticle } from 'src/app/core/models/caisse/ticket-article.model';
import { CategorieArticleFactory } from 'src/app/core/services/caisse/categorie-article.factory';
import { ArticleFactory } from 'src/app/core/services/caisse/article.factory';
import { Ticket } from 'src/app/core/models/caisse/ticket.model';
import { ICaisse } from 'src/app/core/models/caisse/caisse.model';
import { QueryOptions } from 'src/app/shared/models/query-options/query-options.model';
import { TicketFactory } from 'src/app/core/services/caisse/ticket.model';
import { IPointDeVente, PointDeVente } from 'src/app/core/models/caisse/point-vente.model';
import { ITicket } from 'src/app/core/models/caisse/ticket.model';
import { ResourceScrollableHelper } from 'src/app/shared/state/resource.scrollable.helper';
import { ApplicationRef, Component, ComponentFactoryResolver, Injector, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Filter } from 'src/app/shared/models/query-options/filter.model';
import { map, shareReplay } from 'rxjs/operators';
import { IArticle } from 'src/app/core/models/caisse/article.model';
import { NotificationService } from 'src/app/shared';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { cloneable, decycle, retrocycle, shouldDisableSubmit } from 'src/app/shared/helperfonction';
import { CacheService } from 'src/app/shared/services';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Sort } from 'src/app/shared/models/query-options';
import { BehaviorSubject } from 'rxjs';
import { LivraisonEditComponent } from './livraison-edit/livraison-edit.component';
import { deepCopy } from '@angular-devkit/core/src/utils/object';
import {
  DomPortalOutlet,
  PortalOutlet,
  TemplatePortal
} from "@angular/cdk/portal";

enum FilterEnum {
  Tous = 'Tous',
  Devis = 'Devis',
  Commande = 'Commande',
  Vente = 'Vente',
  Cancel = 'Cancel'
}

interface TicketFormState {
  libelle: string,
  date: Date,
  ticketFormData: ITicket,
  ticketArticle: ITicketArticle[],
  removedArticle: number[],
  ticketForm: FormGroup,
  is_updating: boolean,
}

@Component({
  selector: 'app-gestion-caisse',
  templateUrl: 'gestion-caisse.component.html',
  styles: [
    `
    .nav-accent-primary {
    border-bottom-color: #20a8d8!important;
    border-bottom-width: 2px!important;
    }

    .accent-facebook-left {
        border-left: 4px solid #3b5998!important;
    }

    .grid-container {
    margin: 0 auto;
    display: flex;
    transition: 1s ease;
}

.sidebar {
    overflow: auto;
    width: 100%;
    transition: 1s ease;
    position: relative;
}

.main-content {
    overflow: auto;
    width: 0%;
    height: 100%;
    transition: 1s ease;
}

.main-content .card {
    display: none;
}

.main-content_large {
    width: 100%;
}

.main-content_large .card {
    display: flex;
}

.sidebar_small {
    width: 0;
    height: 0;
}

.container {
    width: 900px
}

.card {
    background-color: #fff;
    border: none;
    border-radius: 10px;
    width: 190px;
    /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19) */
}

.image-container {
    position: relative
}

.thumbnail-image {
    border-radius: 10px !important
}

.discount {
    background-color: red;
    padding-top: 1px;
    padding-bottom: 1px;
    padding-left: 4px;
    padding-right: 4px;
    font-size: 10px;
    border-radius: 6px;
    color: #fff
}

.wishlist {
    /* height: 25px;
    width: 25px; */
    background-color: #eee;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)
}

.first {
    position: absolute;
    width: 100%;
    padding: 9px
}

.dress-name {
    font-size: 13px;
    font-weight: bold;
    width: 75%
}

.new-price {
    font-size: 13px;
    font-weight: bold;
    color: red
}

.old-price {
    font-size: 8px;
    font-weight: bold;
    color: grey
}


.creme {
    background-color: #fff;
    border: 2px solid grey
}

.creme:hover {
    border: 3px solid grey
}

.creme:focus {
    background-color: grey
}

.red {
    background-color: #fff;
    border: 2px solid red
}

.red:hover {
    border: 3px solid red
}

.red:focus {
    background-color: red
}

.blue {
    background-color: #fff;
    border: 2px solid #40C4FF
}

.blue:hover {
    border: 3px solid #40C4FF
}

.blue:focus {
    background-color: #40C4FF
}

.darkblue {
    background-color: #fff;
    border: 2px solid #01579B
}

.darkblue:hover {
    border: 3px solid #01579B
}

.darkblue:focus {
    background-color: #01579B
}

.yellow {
    background-color: #fff;
    border: 2px solid #FFCA28
}

.yellow:hover {
    border-radius: 3px solid #FFCA28
}

.yellow:focus {
    background-color: #FFCA28
}

.item-size {
    width: 15px;
    height: 15px;
    border-radius: 50%;
    background: #fff;
    border: 1px solid grey;
    color: grey;
    font-size: 10px;
    text-align: center;
    align-items: center;
    display: flex;
    justify-content: center
}

.rating-star {
    font-size: 10px !important
}

.rating-number {
    font-size: 10px;
    color: grey
}

.buy {
    font-size: 12px;
    color: purple;
    font-weight: 500
}

.voutchers {
    background-color: #fff;
    border: none;
    border-radius: 10px;
    width: 190px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    overflow: hidden
}

.voutcher-divider {
    display: flex
}

.voutcher-left {
    width: 60%
}

.voutcher-name {
    color: grey;
    font-size: 9px;
    font-weight: 500
}

.voutcher-code {
    color: red;
    font-size: 11px;
    font-weight: bold
}

.voutcher-right {
    width: 40%;
    background-color: purple;
    color: #fff
}

.discount-percent {
    font-size: 12px;
    font-weight: bold;
    position: relative;
    top: 5px
}

.off {
    font-size: 14px;
    position: relative;
    bottom: 5px
}

iframe {
  position: absolute;
  top: -10000px;
  left: -10000px;
}


@media print {
  .printable-card {
    page-break-inside: avoid;
  }
}

  `
  ]
})
export class GestionCaisseComponent {
  @ViewChild('AddArticleModal') AddArticleModal;
  @ViewChild("iframe") iframe;
  @ViewChild("ticketDetails") ticketDetails;
  private portalHost: PortalOutlet;

  ticketHelper: ResourceScrollableHelper;
  ticketFormData: ITicket;
  caisse: ICaisse;
  point_vente: IPointDeVente;
  modalData:ITicket;
  is_updating = false;
  filter: FilterEnum = FilterEnum.Tous;
  filterEnum = FilterEnum;
  articleHelper: ResourceScrollableHelper;
  ticketArticle: ITicketArticle[] = [];
  livraison: any;
  removedArticle: number[] = [];
  removedAbonnement = false;
  removedLivraison = false;
  showCancel = true;
  savedState: TicketFormState[] = [];
  codeAvoir: string;
  is_checking_avoir = false;
  @Input() canAddDevis = true;

  onCheckAvoir() {
    this.is_checking_avoir = true;
    const service = new TicketAvoirFactory();
    service.list(
     new QueryOptions(
        [
            {or: true, filters:[new Filter('libelle', this.codeAvoir, 'eq')]}
        ]
      )
    ).subscribe(
      (data)=> {
        this.is_checking_avoir = false;
        if(data.data && data.data.length) {
          data.data[0];
          this.codeAvoir = '';
          const control = this.ticketForm.get('paiementAvoirs') as FormArray;
          control.push(
            new FormGroup({
              id: new FormControl(data.data[0].id,Validators.required),
              disponible: new FormControl(data.data[0].somme-data.data[0].utiliser,Validators.required),
              libelle: new FormControl(data.data[0].libelle,Validators.required),
              utiliser: new FormControl(0,Validators.required),
            })
          );
          return;
        }
        this.notificationService.onInfo('Aucun avoir trouvé')
      }
    )
  }

  readonly allCategories$ = new CategorieArticleFactory().list().pipe(
    shareReplay(1),
    map(data => data.data)
  );

  total: number=0;

  remiseForm = new FormGroup({
    pourcentage: new FormControl('',Validators.required),
    valeur: new FormControl('',Validators.required),
  });

  addArticleForm = new FormGroup({
    remise_pourcentage: new FormControl(0,Validators.required),
    remise: new FormControl(0,Validators.required),
    quantite: new FormControl(1,Validators.required),
    prix: new FormControl(0,Validators.required),
    autre_article: new FormControl('',Validators.required),
  });

  remiseFormSubmit: Function;

  onChangesAddArticleForm(): void {
    let control = this.remiseForm.get('pourcentage') as FormArray;
    const sub1 = control.valueChanges.subscribe(val => {
      if(val) {
        this.remiseForm.get('valeur').setValidators([Validators.required, Validators.max(100)])
      } else {
        this.remiseForm.get('valeur').setValidators([Validators.required]);
      }
      this.remiseForm.get('valeur').updateValueAndValidity();
    });
  }

  onChangesRemiseForm(): void {
    let control = this.remiseForm.get('pourcentage') as FormArray;
    const sub1 = control.valueChanges.subscribe(val => {
      if(val) {
        this.remiseForm.get('valeur').setValidators([Validators.required, Validators.max(100)])
      } else {
        this.remiseForm.get('valeur').setValidators([Validators.required]);
      }
      this.remiseForm.get('valeur').updateValueAndValidity();
    });
  }

  onChangesTicketForm(): void {
    let control = this.ticketForm.get('pourcentage') as FormArray;
    const sub1 = control.valueChanges.subscribe(val => {
      if(val) {
        this.ticketForm.get('valeur').setValidators([Validators.required, Validators.max(100)])
      } else {
        this.ticketForm.get('valeur').setValidators([Validators.required]);
      }
      this.ticketForm.get('valeur').updateValueAndValidity();
    });
  }

  shouldShowMaxError( controlName: string, form: FormArray) {
    const control = form.get(controlName);
    if (control) {
      return (control.dirty || control.touched) && control.hasError('max');
    }
  }

  shouldDisableRemiseSubmit = () => shouldDisableSubmit(this.remiseForm);
  shouldDisableAddArticleSubmit = () => shouldDisableSubmit(this.addArticleForm);


  typeReduction = [
    {
      id: 0,
      libelle: 'montant',
    },
    {
      id: 1,
      libelle: 'pourcentage',
    }
  ];

  openRemiseArticleModal(content, data: ITicketArticle) {
    this.modalService.open(content, { size: 'lg', centered: true,  backdrop: 'static' });
    this.remiseForm = new FormGroup({
      pourcentage: new FormControl(data.remise_pourcentage,Validators.required),
      valeur: new FormControl(data.remise,Validators.required),
    });
    this.onChangesRemiseForm();
    this.remiseFormSubmit = ()=>{
      this.ticketArticle = this.ticketArticle.map(element => {
        if (element.article_id === data.article_id ) {
          element.remise = this.remiseForm.get('valeur').value;
          element.remise_pourcentage = this.remiseForm.get('pourcentage').value;
        }
        return element;
    });
    this.onSetSum();
    }
  }

  openRemiseTicketModal(content) {
    this.modalService.open(content, { size: 'lg', centered: true,  backdrop: 'static' });
    this.remiseForm = new FormGroup({
      pourcentage: new FormControl(this.ticketForm.get('pourcentage').value,Validators.required),
      valeur: new FormControl(this.ticketForm.get('valeur').value,Validators.required),
    });
    this.onChangesRemiseForm();
    this.remiseFormSubmit = ()=>{
      this.ticketForm.get('pourcentage').setValue(
        this.remiseForm.get('pourcentage').value
      );
      this.ticketForm.get('valeur').setValue(
        this.remiseForm.get('valeur').value
      );
    }
  }

  openAddArticleModal() {
    this.modalService.open(this.AddArticleModal, { size: 'lg', centered: true,  backdrop: 'static' });

    this.addArticleForm = new FormGroup({
      remise_pourcentage: new FormControl(0,Validators.required),
      remise: new FormControl(0,Validators.required),
      quantite: new FormControl(1,Validators.required),
      prix: new FormControl(0,Validators.required),
      libelle: new FormControl('',Validators.required),
    });

    this.onChangesAddArticleForm();
  }

  onAddArticleFormSubmit() {
    let ticketArt = new TicketArticle();
    ticketArt.autre_article = this.addArticleForm.get('libelle').value;
    ticketArt.quantite = this.addArticleForm.get('quantite').value;
    ticketArt.prix = this.addArticleForm.get('prix').value;
    ticketArt.remise = this.addArticleForm.get('remise').value;
    ticketArt.remise_pourcentage = this.addArticleForm.get('remise_pourcentage').value;
    ticketArt.article_id = null;
    this.ticketArticle.push(ticketArt);
    this.onSetSum();
  }

  @Input() set initCaisse(initData:{caisse: ICaisse, point_vente: IPointDeVente}) {
    this.articleHelper = new ResourceScrollableHelper(
      new ArticleFactory(), new QueryOptions([])
    );
    this.articleHelper.withoutPaginate = true;
    this.articleHelper.loadData(1);

    this.ticketArticle = [];
    this.removedArticle = [];
    let query = new QueryOptions([]);
    query.setSort([new Sort('created_at','DESC')]);

    if(initData.caisse) {
      if(query.filter_groups.length) {
        query.filter_groups[0].filters.push(
          new Filter('caisse', initData.caisse.id, 'eq')
        )
      }  else {
        query.filter_groups =  [
          {or: false, filters:[new Filter('caisse', initData.caisse.id, 'eq')]},
        ];
      }
    }

    if(initData.point_vente) {
      if(query.filter_groups.length) {
        query.filter_groups[0].filters.push(
          new Filter('point_vente', initData.point_vente.id, 'eq')
        )
        } else {
          query.filter_groups =  [
            {or: false, filters:[new Filter('point_vente', initData.point_vente.id, 'eq')]},
          ];
      }
    }

    this.ticketHelper = new ResourceScrollableHelper(
      new TicketFactory(), query
    );
    this.caisse = initData.caisse ;
    this.point_vente = initData.point_vente;
    this.ticketHelper.relations = ['ca_livraison','ca_abonnement','ca_moyen_paiement', 'ca_ticket_articles.ca_article', 'ca_paiement_avoirs.ca_ticket_avoir']
    // this.ticketHelper.searchCustomFilterGroup = {or: true, filters:[new Filter('point_vente', this.point_vente.id, 'eq')]}
    this.ticketHelper.loadData(1);

    this.ticketForm =new FormGroup({
      moyen_paiement_id: new FormControl('',Validators.required),
      somme: new FormControl('',Validators.required),
      pourcentage: new FormControl(0,Validators.required),
      valeur: new FormControl(0,Validators.required),
      non_attribuer: new FormControl(0,Validators.required),
      avoir: new FormControl(0,Validators.required),
      abonnement_id: new FormControl(null),
      paiementAvoirs: new FormArray([])
    });
    this.onChangesTicketForm();
    this.ticketFormStep2 =false;
  }

  removePaimentAvoir(child_index) {
    const control = this.ticketForm.get('paiementAvoirs') as FormArray;
    control.markAsDirty();
    control.removeAt(child_index);
  }

  onChangeTicketFilter(filter: FilterEnum) {
    this.filter = filter;
    switch(filter) {
      case FilterEnum.Commande:
      this.ticketHelper.searchCustomFilterGroup = {or: false, filters:[
        new Filter('devis', 0, 'eq'),new Filter('somme', '', 'eq')
      ]};
      break;
      case FilterEnum.Devis:
      this.ticketHelper.searchCustomFilterGroup = {or: false, filters:[
        new Filter('devis', 1, 'eq'),new Filter('somme', '', 'eq')
      ]};
      break;
      case FilterEnum.Vente:
      this.ticketHelper.searchCustomFilterGroup = {or: false, filters:[
        new Filter('somme', '', 'eq', true)
      ]};
      break;
      default:
      this.ticketHelper.searchCustomFilterGroup = {or: false, filters:[
      ]};
      break;
    }

    if(!this.showCancel) {
      this.ticketHelper.searchCustomFilterGroup.filters.push(
        new Filter('deleted_at', '', 'eq')
      );
    }

    this.ticketHelper.loadData(1);
  }

  onSwitchCancelFilter() {
    this.showCancel = !this.showCancel;
    this.onChangeTicketFilter(this.filter);
  }

  ticketForm = new FormGroup({
    moyen_paiement_id: new FormControl('',Validators.required),
    somme: new FormControl('',Validators.required),
    pourcentage: new FormControl(0,Validators.required),
    valeur: new FormControl(0,Validators.required),
    non_attribuer: new FormControl(0,Validators.required),
    avoir: new FormControl(0,Validators.required),
    abonnement_id: new FormControl(null),
    paiementAvoirs: new FormArray([])
  });
  ticketFormStep2 =false;
  is_form_saving = false;
  shouldDisableBatimentSubmit = () => shouldDisableSubmit(this.ticketForm);

  readonly allMoyenPaiements$ = this.cacheService.get(
    'allMoyenPaiements',
    new MoyenPaiementFactory().list().pipe(
      shareReplay(1),
      map(data => data.data)
    ),
    1800000);

  constructor(
    protected notificationService: NotificationService,
    protected cacheService: CacheService,
    protected modalService: NgbModal,
    private componentFactoryResolver: ComponentFactoryResolver,
    private injector: Injector,
    private appRef: ApplicationRef,
    private viewContainerRef: ViewContainerRef

  ) { }

  printMainContent(): void {

    const iframe = this.iframe.nativeElement;
    this.portalHost = new DomPortalOutlet(
      iframe.contentDocument.body,
      this.componentFactoryResolver,
      this.appRef,
      this.injector
    );

    const portal = new TemplatePortal(
      this.ticketDetails,
      this.viewContainerRef,
      {
        ticket: this.modalData
      }
    );

    // Attach portal to host
    this.portalHost.attach(portal);
    iframe.contentWindow.onafterprint = () => {
      iframe.contentDocument.body.innerHTML = "";
    };
    this._attachStyles(iframe.contentWindow);
    this.waitForImageToLoad(
      iframe,
      () => iframe.contentWindow.print()
    );
  }


  private waitForImageToLoad(iframe: HTMLIFrameElement, done: Function): void {
    const interval = setInterval(() => {
      const allImages = iframe.contentDocument.body.querySelectorAll(
        "img"
      );
      const loaded = Array.from({ length: allImages.length }).fill(false);
      allImages.forEach((img: HTMLImageElement, idx) => {
        loaded[idx] = img.complete;
      });
      if (loaded.every(c => c === true)) {
        clearInterval(interval);
        done();
      }
    }, 500);
  }

  private _attachStyles(targetWindow: Window): void {
    // Copy styles from parent window
    document.querySelectorAll("style").forEach(htmlElement => {
      targetWindow.document.head.appendChild(htmlElement.cloneNode(true));
    });
    // Copy stylesheet link from parent window
    const styleSheetElement = this._getStyleSheetElement();
    targetWindow.document.head.appendChild(styleSheetElement);
  }

  private _getStyleSheetElement() {
    const styleSheetElement = document.createElement("link");
    document.querySelectorAll("link").forEach(htmlElement => {
      if (htmlElement.rel === "stylesheet") {
        const absoluteUrl = new URL(htmlElement.href).href;
        styleSheetElement.rel = "stylesheet";
        styleSheetElement.type = "text/css";
        styleSheetElement.href = absoluteUrl;
      }
    });
    console.log(styleSheetElement.sheet);
    return styleSheetElement;
  }


  onOpenStateModal()
  {
    const dataSource$ = new BehaviorSubject<TicketFormState[]>(this.savedState);
    const modalRef = this.modalService.open(ChooseStateComponent,{  centered: true,  backdrop: 'static' });
    const instance = modalRef.componentInstance as ChooseStateComponent;
    instance.canAddItem = true;
    instance.dataSource$ =  dataSource$;
    instance.formLibelle = 'Sauvegarde';
    instance.title = 'Sauvegarder cet élément'
    instance.itemCreated.subscribe(
      (data: {libelle: string})=> {
        this.savedState.push({
          date: new Date,
          is_updating: this.is_updating,
          libelle: data.libelle,
          removedArticle: this.removedArticle,
          ticketArticle: this.ticketArticle,
          ticketFormData: this.ticketFormData,
          ticketForm: this.ticketForm
        });
        console.log({
          date: new Date,
          is_updating: this.is_updating,
          libelle: data.libelle,
          removedArticle: this.removedArticle,
          ticketArticle: this.ticketArticle,
          ticketFormData: this.ticketFormData,
          ticketForm: this.ticketForm
        });

        let test = JSON.stringify(decycle({
          date: new Date,
          is_updating: this.is_updating,
          libelle: data.libelle,
          removedArticle: this.removedArticle,
          ticketArticle: this.ticketArticle,
          ticketFormData: this.ticketFormData,
          ticketForm: this.ticketForm
        }, undefined));
        console.log(test);
        console.log(retrocycle(JSON.parse(test)));
        dataSource$.next(this.savedState);
        this.onResetForm();
        instance.onCloseModal('saved');
      }
    );
    instance.itemChoosen.subscribe(
      (data: TicketFormState)=> {
        this.ticketFormData = data.ticketFormData;
        this.is_updating = data.is_updating;
        this.ticketArticle = data.ticketArticle;
        this.removedArticle = data.removedArticle;
        this.ticketForm = data.ticketForm;
        this.ticketFormStep2 =false;
        this.onSetSum();
      }
    );
    instance.itemRemove.subscribe(
      (data: TicketFormState)=> {
        const index = this.savedState.findIndex(element => element.date === data.date);
        this.savedState.splice(index, 1);
        dataSource$.next(this.savedState);
      }
    )
  }

  onSetSum() {
   this.total=  this.ticketArticle.filter((item) =>item.quantite)
                .map((item) => item.quantite*item.prix_avec_remise)
                .reduce((sum, current) => sum + current,0);
  }

  get totalWRemise(){
    const avoir = this.ticketForm.get('paiementAvoirs').value.filter((item) =>item.utiliser)
                .map((item) => item.utiliser)
                .reduce((sum, current) => sum + current,0);
    if((!this.ticketForm)|| !this.ticketForm.get('valeur').value) {
      return this.total - avoir;
    }

    if(this.ticketForm.get('pourcentage').value) {
      return this.total - avoir - ((this.total/100)*this.ticketForm.get('valeur').value)
    }

    return this.total - avoir - this.ticketForm.get('valeur').value
  }


  openValidationModal(content) {
    this.onSetSum();
    this.modalService.open(content, { size: 'lg', centered: true,  backdrop: 'static' });
  }

  openModal(content, data: ITicket) {
    this.modalData = data;
    this.modalService.open(content, { size: 'lg', centered: true,  backdrop: 'static' });
  }

  openLivraisonModal() {
    const componentRef = this.modalService.open(LivraisonEditComponent, { size: 'lg', centered: true,  backdrop: 'static' });
    const instance = componentRef.componentInstance as LivraisonEditComponent;
    if(this.ticketFormData.livraison) {
      instance.defaultValue = this.ticketFormData.livraison;
    } else if (this.ticketFormData.abonnement) {
      instance.defaultValue = {
        id: null,
        type_destinataire: 'abonne',
        livreur: null,
        secteur: null,
        addresse: this.ticketFormData.abonnement ? this.ticketFormData.abonnement.addresse : this.ticketFormData.abonnement.entreprise.addresse,
        date: new Date(),
        plage_horaire: null,
        abonnement: this.ticketFormData.abonnement,
        note: null,
        receptionnaire: {
          id: null,
          nom_receptionnaire: null,
          type_receptionnaire: null,
          categorie_client: null,
          telephone: null,
          addresse: null
        }
      };
    }
    instance.choosedItem.subscribe(
      (data)=> {
        this.livraison = data.formData;
        this.ticketFormData.livraison = data.itemData;
        if(this.ticketFormData.livraison.abonnement && !this.ticketFormData.abonnement) {
          this.ticketForm.get('abonnement_id').setValue(this.ticketFormData.livraison.abonnement.id);
          this.ticketFormData.abonnement = this.ticketFormData.livraison.abonnement;
          this.removedAbonnement = false;
        }
        this.removedLivraison = false;
      }
    )
  }

  onRemoveLivraison() {
    if((!this.ticketFormData.livraison_id) || !this.is_updating) {
      this.ticketFormData.livraison = null;
      this.livraison =  null;
      this.removedLivraison = true;
      return;
    }
   this.notificationService.title = 'Supprimer';
   this.notificationService.body = 'Êtes-vous sûr(e) de vouloir supprimer cette livraison?';

   let confirm = () => {
    this.ticketFormData.livraison = null;
    this.livraison =  null;
    this.removedLivraison = true;
   };

   let cancel = () => {
   };

   this.notificationService.bodyMaxLength = 300;
   this.notificationService.backdrop =  0;
   this.notificationService.onConfirmation(confirm, cancel);

   this.notificationService.bodyMaxLength = 80;
   this.notificationService.backdrop =  -1;
  }

  openClientModal() {
   const componentRef = this.modalService.open(ChooseAbonnementComponent, { size: 'lg', centered: true,  backdrop: 'static' });
   const instance = componentRef.componentInstance as ChooseAbonnementComponent;
   instance.choosedItem.subscribe(
     (data)=>{
       this.ticketForm.get('abonnement_id').setValue(data[0].id);
       this.ticketFormData.abonnement = data[0];
       this.removedAbonnement = false;
     }
   )
  }

  onRemoveClient() {
    this.ticketForm.get('abonnement_id').setValue(null);
    this.ticketFormData.abonnement = null;
    this.removedAbonnement = true;
  }


  onShowForm() {
    this.onResetForm();
    this.ticketFormData = new Ticket();
    this.is_updating = false;
    this.onSetSum();
    // this.ticketFormData.point_vente_id = this.point_vente.id;
  }

  onShowUpdateForm(ticket: ITicket) {
    this.ticketFormData = cloneable.deepCopy<Ticket>(ticket);
    this.is_updating = true;
    this.ticketArticle = this.ticketFormData.articleTickets;
    this.ticketForm =new FormGroup({
      moyen_paiement_id: new FormControl(ticket.moyen_paiement_id,Validators.required),
      somme: new FormControl(ticket.somme,Validators.required),
      pourcentage: new FormControl(ticket.remise_pourcentage,Validators.required),
      valeur: new FormControl(ticket.remise,Validators.required),
      non_attribuer: new FormControl(ticket.non_attribuer,Validators.required),
      avoir: new FormControl(0,Validators.required),
      abonnement_id: new FormControl(ticket.abonnement_id),
      paiementAvoirs: new FormArray([])
    });
    this.onChangesTicketForm();
    this.ticketFormStep2 =false;
    this.onSetSum();
  }

  onSetUpdateFormData(ticket: ITicket) {
    this.is_updating = true;
    this.ticketFormData = cloneable.deepCopy<Ticket>(ticket);
    this.ticketArticle =this.ticketFormData.articleTickets;
    this.ticketForm =new FormGroup({
      moyen_paiement_id: new FormControl(ticket.moyen_paiement_id,Validators.required),
      somme: new FormControl(ticket.somme,Validators.required),
      pourcentage: new FormControl(ticket.remise_pourcentage,Validators.required),
      valeur: new FormControl(ticket.remise,Validators.required),
      non_attribuer: new FormControl(ticket.non_attribuer,Validators.required),
      avoir: new FormControl(0,Validators.required),
      abonnement_id: new FormControl(ticket.abonnement_id),
      paiementAvoirs: new FormArray([])
    });
    this.onChangesTicketForm();
    this.ticketFormStep2 =false;
    this.onSetSum();
  }

  onResetForm()
 {
  this.ticketFormData = null;
  this.ticketArticle = [];
  this.removedArticle = [];
  this.ticketForm =new FormGroup({
    moyen_paiement_id: new FormControl('',Validators.required),
    somme: new FormControl('',Validators.required),
    pourcentage: new FormControl(0,Validators.required),
    valeur: new FormControl(0,Validators.required),
    non_attribuer: new FormControl(0,Validators.required),
    avoir: new FormControl(0,Validators.required),
    abonnement_id: new FormControl(null),
    paiementAvoirs: new FormArray([])
  });
  this.onChangesTicketForm();
  this.ticketFormStep2 =false;
 }

 onCancelPurchase() {
   if(this.is_updating) {
     return this.onResetForm();
   }
  this.notificationService.title = 'Annulation';
  this.notificationService.body = 'Êtes-vous sûr(e) de vouloir annuler cette facture?';

  let confirm = () => {
    this.onResetForm();
  };

  let cancel = () => {
  };
  this.notificationService.bodyMaxLength = 300;
  this.notificationService.backdrop =  0;
  this.notificationService.onConfirmation(confirm, cancel);

  this.notificationService.bodyMaxLength = 80;
  this.notificationService.backdrop =  -1;

 }

  onChangeArticleFilter(categorie_id: number) {
    if(categorie_id) {
      this.articleHelper.searchCustomFilterGroup = {or: true, filters:[new Filter('categorie_id', categorie_id, 'eq')]}
      this.articleHelper.loadData(1);
      return;
    }
    this.articleHelper.searchCustomFilterGroup = null;
  }

  onAddArticletoTicket(article: IArticle) {
    if(this.ticketArticle.filter((data)=>data.article_id == article.id).length) {
      this.ticketArticle= this.ticketArticle.map(
        (data)=> {
          if(data.article_id == article.id) {
            data.quantite +=1;
          }
          return data;
        }
      )
      this.onSetSum();
      return;
    }
    let ticketArt = new TicketArticle();
    ticketArt.article = article;
    ticketArt.quantite = 1;
    ticketArt.prix = article.prix;
    ticketArt.article_id = article.id;
    this.ticketArticle.push(ticketArt);
    this.onSetSum();
  }

  removeItem(item: ITicketArticle) {
    this.notificationService.title = 'Suppréssion';
    this.notificationService.body = 'Êtes-vous sûr(e) de vouloir Retirer?' + ' ' + item.libelle;

    let confirm = () => {
      if(item.id) {
        this.removedArticle.push(item.id);
      }
      this.ticketArticle = this.ticketArticle.filter(element => element !== item);
      this.onSetSum();
    };

    let cancel = () => {
    };

    this.notificationService.bodyMaxLength = 300;
    this.notificationService.backdrop =  0;
    this.notificationService.onConfirmation(confirm, cancel);

    this.notificationService.bodyMaxLength = 80;
    this.notificationService.backdrop =  -1;
  }

  onSaveWOValidation(content, devis = 0) {
    this.is_form_saving = true;
    const data = {
      id: this.ticketFormData.id,
      articles: this.ticketArticle,
      avoir: this.ticketForm.get('avoir').value,
      remise: this.ticketForm.get('valeur').value,
      non_attribuer:this.ticketForm.get('non_attribuer').value,
      devis: devis,
      abonnement_id: this.ticketForm.get('abonnement_id').value,
      remise_pourcentage: this.ticketForm.get('pourcentage').value,
      removedArticle: this.removedArticle
    };

    if(this.caisse) {
      data['caisse'] = this.caisse.id;
    }

    if(this.point_vente) {
      data['point_vente'] = this.point_vente.id;
    }

    if(this.removedAbonnement) {
      data['removedAbonnement'] = true;
    }

    if(this.livraison) {
      data['livraison'] = this.livraison;
    }

    if(this.removedLivraison) {
      data['removedLivraison'] = true;
    }

    if(this.ticketFormData.livraison_id) {
      data['livraison_id']= this.ticketFormData.livraison_id;
    }

    const service = new TicketFactory();
    const saveFunction = this.is_updating ?  (item)=>service.update(item) : (item)=>service.create(item);
    saveFunction(data).subscribe(
        (data) => {
            this.is_form_saving = false;
            if(this.is_updating) {
              this.ticketHelper.updateItem(data);
            } else {
              this.ticketHelper.addItem(data);
            }
            this.openModal(content, data);
            this.notificationService.onSuccess('Toutes les modifications ont été enregistré');
            this.onResetForm();
        }, error => {
        if (error.status == 500) {
          this.notificationService.onError('Impossible d\'éffectuer cette requête');
          this.is_form_saving = false;
        }
      });
  }

  onSaveTicket(content) {
    this.is_form_saving = true;

    const data = {
      id: this.ticketFormData.id,
      moyen_paiement_id: this.ticketForm.get('moyen_paiement_id').value,
      somme: this.ticketForm.get('somme').value,
      articles: this.ticketArticle,
      avoir: this.ticketForm.get('avoir').value,
      remise: this.ticketForm.get('valeur').value,
      remise_pourcentage: this.ticketForm.get('pourcentage').value,
      removedArticle: this.removedArticle,
      abonnement_id: this.ticketForm.get('abonnement_id').value,
      non_attribuer:this.ticketForm.get('non_attribuer').value,
      paiementAvoirs: this.ticketForm.get('paiementAvoirs').value
    };


    if(this.caisse) {
      data['caisse'] = this.caisse.id;
    }

    if(this.point_vente) {
      data['point_vente'] = this.point_vente.id;
    }

    if(this.removedAbonnement) {
      data['removedAbonnement'] = true;
    }

    if(this.livraison) {
      data['livraison'] = this.livraison;
    }

    if(this.removedLivraison) {
      data['removedLivraison'] = true;
    }

    if(this.ticketFormData.livraison_id) {
      data['livraison_id']= this.ticketFormData.livraison_id;
    }

    const service = new TicketFactory();
    const saveFunction = this.is_updating ?  (item)=>service.update(item) : (item)=>service.create(item);
    saveFunction(data).subscribe(
        (data) => {
            this.is_form_saving = false;
            if(this.is_updating) {
              this.ticketHelper.updateItem(data);
            } else {
              this.ticketHelper.addItem(data);
            }
            this.openModal(content, data);
            this.notificationService.onSuccess('Toutes les modifications ont été enregistré');
            this.onResetForm();
        }, error => {
        if (error.status == 500) {
          this.notificationService.onError('Impossible d\'éffectuer cette requête');
          this.is_form_saving = false;
        }
      });
  }

  onDeleteTicket(item: ITicket, close?: (raison?)=>{}) {
    this.notificationService.title = 'Annuler';

    this.notificationService.body = 'Êtes-vous sûr(e) de vouloir annuler?';

    const confirm = () => {
      this.ticketHelper.service.delete(item.id).subscribe(
          () => {
            item.cancel = true;
            this.ticketHelper.updateItem(item);
            this.notificationService.onSuccess("L'élément a été annulé");
            if(close) {
              close('Close delete');
            }
            this.onResetForm();
          }, () => {
            this.notificationService.onInfo('l\'élément est utilisé');
          }
        );
    };

    const cancel = () => {
    };

    this.notificationService.bodyMaxLength = 300;
    this.notificationService.backdrop =  0;
    this.notificationService.onConfirmation(confirm, cancel);

    this.notificationService.bodyMaxLength = 80;
    this.notificationService.backdrop =  -1;
  }
}
